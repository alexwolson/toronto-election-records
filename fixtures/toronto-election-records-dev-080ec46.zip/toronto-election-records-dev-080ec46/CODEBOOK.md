# Codebook

Toronto Election Results, version `dev-080ec46`. Package schema 1.0.0.

Each table comes in four files with the same rows and columns: CSV (UTF-8, an empty field is a null), Parquet, Stata (`.dta`) and R (`.rds`). In the Stata files a boolean is stored as 0 or 1 with the value labels `false` and `true`, and a null string is empty. Dates are polling days and other calendar dates, written as `YYYY-MM-DD` in the CSV files.

| Table | One row per | Key |
|---|---|---|
| `elections` | Election event | `event_id` |
| `contests` | Contest | `contest_id` |
| `candidacies` | Candidacy | `candidacy_id` |
| `people` | active Person | `person_id` |
| `person_id_redirects` | retired Person ID | `retired_person_id` |
| `office_tenures` | piece of evidence that a Person held an office | `office_tenure_id` |
| `parties` | Party | `party_id` |
| `districts` | district | `district_id` |

## `elections`

Election events. One row per Election event. An Election event is one general election or one by-election, called by one authority. By-elections called separately are separate events even when they share a polling day.

Key: `event_id`.

- **`event_id`** (string, never null). Stable ID of the Election event.
- **`election_date`** (date, never null). The day of the vote.
- **`election_year`** (integer, never null). The year of `election_date`.
- **`election_type`** (string, never null). Whether the event is a general election or a by-election.  
  Values: `general`, `by_election`.
- **`election_authority`** (string, never null). The authority that ran the election. The clerks of the six former municipalities ran the 1994 municipal and school board elections and North York's 1995 by-election; the City Clerk has run every municipal election since 1997.  
  Values: `toronto_city_clerk`, `elections_canada`, `elections_ontario`, `former_toronto_city_clerk`, `east_york_borough_clerk`, `etobicoke_city_clerk`, `north_york_city_clerk`, `scarborough_city_clerk`, `york_city_clerk`.

## `contests`

Contests. One row per Contest. A Contest is one race for one or more seats in one district at one Election event. Void Contests are included and have no Candidacies.

Key: `contest_id`.
Joins: `event_id` to `elections`, `district_id` to `districts`.

- **`contest_id`** (string, never null). Stable ID of the Contest.
- **`event_id`** (string, never null). The Election event the Contest belongs to.
- **`represented_body`** (string, never null). The body whose seats the Contest fills, such as `toronto_city_council`, `toronto_district_school_board` or `canada_house_of_commons`. The 1994 bodies are those of the former municipalities and Metropolitan Toronto.
- **`office_type`** (string, never null). The office contested.  
  Values: `mayor`, `councillor`, `trustee`, `mp`, `mpp`.
- **`district_id`** (string, never null). The district the Contest was run in, as it was drawn at the time. A citywide race, such as Mayor, has a district for the whole City.
- **`official_district_id`** (string, never null). The authority's own number or code for the district.
- **`district_name`** (string, never null). The district's name as the authority gave it. A district keeps one name within its boundary set, so a riding renamed between two elections under the same boundaries keeps its first name.
- **`boundary_regime`** (string, never null). The set of district boundaries the Contest was run under, such as `toronto_council_25_wards` or `federal-2013-representation-order`. Districts in different boundary sets cover different areas and cannot be compared directly, even when they share a name or number.
- **`outcome_method`** (string, never null). How the Contest was decided: by vote, by Acclamation (no more candidates than seats), or `void` when the election was declared void and no result stands.  
  Values: `vote`, `acclamation`, `void`.
- **`coverage_status`** (string, never null). `complete` when the sources give every candidate's votes and the winners. `partial` when they do not, in which case some `votes`, totals or `elected` values are null. See KNOWN_ISSUES.md for the partial Contests.  
  Values: `complete`, `partial`.
- **`acclaimed`** (boolean, never null). True when the Contest was decided by Acclamation.
- **`n_candidates`** (integer, can be null). The number of Candidacies in the Contest.  
  Null for void Contests, which have no Candidacies.
- **`seats_available`** (integer, never null). The number of members the Contest elects. Every Contest from 2003 on elects one. Every 1997 council ward elected two, as did East York's 1994 council and school wards, five 1994 Toronto Board of Education wards and several 1994 French-language areas.
- **`total_contest_votes`** (integer, can be null). The sum of valid votes for every candidate in the Contest. It is the denominator of `vote_share`.  
  Units: votes.  
  Null for Acclamations and void Contests, where no votes were counted, and for partial Contests whose sources omit some votes.
- **`eligible_electors`** (integer, can be null). The number of electors the authority reports, at the scope in `turnout_scope`.  
  Units: electors.  
  Null when the authority's source gives no count. That is the case for every trustee Contest, every municipal Contest from 1994 to 2001, the 2026 municipal election (until the City publishes its voter statistics) and the 2026 Scarborough Southwest provincial by-election.
- **`ballots_cast`** (integer, can be null). The number of electors who voted, at the same scope as `eligible_electors`.  
  Units: ballots.  
  Null under the same conditions as `eligible_electors`.
- **`turnout`** (number, can be null). `ballots_cast` divided by `eligible_electors`.  
  Units: share between 0 and 1.  
  Null when either count is null.
- **`turnout_scope`** (string, can be null). What the two turnout counts cover. `composite_municipal_ballot` is the City's count of electors who cast a municipal ballot in the ward, which is shared by the Mayor and Councillor races; it is not a count for any one race. Federal and Ontario counts are for the riding.  
  Values: `composite_municipal_ballot`, `federal_electoral_district`, `provincial_electoral_district`.  
  Null when the turnout counts are null.
- **`source_authority`** (string, never null). The organization whose record the Contest comes from: the election authority, or the Toronto Star where only the newspaper's printed results survive (most 1994 and 1997 trustee Contests and eight 1994 council Contests).  
  Values: `Toronto City Clerk`, `Elections Canada`, `Elections Ontario`, `Toronto Star`.
- **`source_url`** (string, never null). The published URL of each record the Contest comes from, separated by `;`. Where the record is a file inside an archive or one part of a page, the provenance supplement's `source_detail` names the file or part.

## `candidacies`

Candidacies. One row per Candidacy. A Candidacy is one person's appearance on the ballot in one Contest. Labels from the Contest and the Election event are repeated on each row so the table can be used on its own. `person_id` joins the runs of one person across Contests, offices and years.

Key: `candidacy_id`.
Joins: `event_id` to `elections`, `contest_id` to `contests`, `district_id` to `districts`, `incumbent_held_district_id` to `districts`, `party_id` to `parties`, `person_id` to `people`.

- **`candidacy_id`** (string, never null). Stable ID of the Candidacy.
- **`person_id`** (string, can be null). The Person who ran. A link is made only from evidence; similar names alone never make one. `person_link_basis` says what the link rests on.  
  Null when the evidence does not establish who ran, or the only proposed Person was rejected.
- **`person_link_basis`** (string, can be null). What the link from this Candidacy to its Person rests on. `own_record`: the Person was made from this Candidacy, so the link joins it to no earlier or later run. `official_record`: an official record ties the runs, such as incumbency the authority reported or a Council roster. `person_specific_source`: a source about the person ties the runs, such as a biography, a news report or a candidate profile. `structural`: no source about the person was found, and the runs are joined under the build's structural rules. To keep only links that a source confirms, treat Candidacies with `structural` as having no Person.  
  Values: `own_record`, `official_record`, `person_specific_source`, `structural`.  
  Null when `person_id` is null.
- **`event_id`** (string, never null). The Election event.
- **`contest_id`** (string, never null). The Contest.
- **`election_date`** (date, never null). Polling day, repeated from `elections`.
- **`election_year`** (integer, never null). The year of polling day, repeated from `elections`.
- **`election_type`** (string, never null). Repeated from `elections`.  
  Values: `general`, `by_election`.
- **`election_authority`** (string, never null). Repeated from `elections`.  
  Values: `toronto_city_clerk`, `elections_canada`, `elections_ontario`, `former_toronto_city_clerk`, `east_york_borough_clerk`, `etobicoke_city_clerk`, `north_york_city_clerk`, `scarborough_city_clerk`, `york_city_clerk`.
- **`represented_body`** (string, never null). Repeated from `contests`.
- **`office_type`** (string, never null). Repeated from `contests`.  
  Values: `mayor`, `councillor`, `trustee`, `mp`, `mpp`.
- **`district_id`** (string, never null). Repeated from `contests`.
- **`official_district_id`** (string, never null). Repeated from `contests`.
- **`district_name`** (string, never null). Repeated from `contests`.
- **`boundary_regime`** (string, never null). Repeated from `contests`.
- **`candidate_name`** (string, never null). The candidate's name, given name first. The City's poll-by-poll files print names surname first; where the split is unclear, the Clerk's declaration of results sets the order.
- **`candidate_name_raw`** (string, never null). The candidate's name exactly as the source printed it.
- **`party_id`** (string, can be null). The Party the candidate ran for. Parties are recorded only in federal and Ontario races; municipal races are non-partisan.  
  Null when `affiliation_status` is not `party`.
- **`party_name`** (string, can be null). The Party's name, repeated from `parties.canonical_name`.  
  Null when `party_id` is null.
- **`affiliation_status`** (string, never null). `party` when the candidate ran for a Party, `independent` when they ran as an independent in a federal or Ontario race, `non_partisan` in every municipal and trustee race, and `not_reported` when the source gives no affiliation.  
  Values: `party`, `independent`, `non_partisan`, `not_reported`.
- **`votes`** (integer, can be null). Valid votes for the candidate, as certified. Zero means the candidate received no votes.  
  Units: votes.  
  Null for Acclamations, where no vote was held, and for the few candidates in partial Contests whose votes the sources do not give.
- **`total_contest_votes`** (integer, can be null). The sum of valid votes for every candidate in the Contest, repeated from `contests`. It is the denominator of `vote_share`.  
  Units: votes.  
  Null for Acclamations and for partial Contests whose sources omit some votes.
- **`vote_share`** (number, can be null). `votes` divided by `total_contest_votes`. In a Contest with more than one seat each voter could cast several votes, so this is a share of votes, not of voters.  
  Units: share between 0 and 1.  
  Null when `votes` or `total_contest_votes` is null.
- **`vote_rank`** (integer, can be null). The candidate's rank by votes within the Contest, 1 for the most. Tied totals share a rank.  
  Null when `total_contest_votes` is null.
- **`n_candidates`** (integer, never null). The number of Candidacies in the Contest.
- **`seats_available`** (integer, never null). The number of members the Contest elects, repeated from `contests`.
- **`elected`** (boolean, can be null). True when the candidate was elected, as the authority certified. Where a source lists votes without marking winners, the top `seats_available` candidates are elected.  
  Null when the sources cannot establish the result: candidates tied across the last seat, or a partial Contest whose winner is unknown.
- **`acclaimed`** (boolean, never null). True when the candidate was elected by Acclamation.
- **`outcome_method`** (string, never null). Repeated from `contests`.  
  Values: `vote`, `acclamation`, `void`.
- **`coverage_status`** (string, never null). Repeated from `contests`.  
  Values: `complete`, `partial`.
- **`eligible_electors`** (integer, can be null). Repeated from `contests`.  
  Units: electors.  
  Null under the conditions given for `contests.eligible_electors`.
- **`ballots_cast`** (integer, can be null). Repeated from `contests`.  
  Units: ballots.  
  Null under the conditions given for `contests.eligible_electors`.
- **`turnout`** (number, can be null). Repeated from `contests`.  
  Units: share between 0 and 1.  
  Null when either count is null.
- **`turnout_scope`** (string, can be null). Repeated from `contests`.  
  Values: `composite_municipal_ballot`, `federal_electoral_district`, `provincial_electoral_district`.  
  Null when the turnout counts are null.
- **`incumbent`** (boolean, can be null). True when the Person held the same office in the same body on the eve of the election, from the body's roster. False when the Person is linked and the roster shows they did not. It is never inferred from a repeated name or an earlier win alone.  
  Null when no Person is linked, or when the release holds no roster that can settle it: Mayor and Council in 1994 and 1997 (see `predecessor_incumbent` for 1997), and every trustee race before 2026.
- **`incumbent_appointed`** (boolean, can be null). True when the incumbent's seat came by appointment to fill a vacancy, false when it came by election.  
  Null when the candidate is not an incumbent, or the tenure does not say, as for the sitting members at the 1995 Ontario election.
- **`incumbent_held_district_id`** (string, can be null). The `district_id` of the seat the incumbent held. It can belong to an earlier boundary set than the Candidacy's district.  
  Null when the candidate is not an incumbent, the tenure gives no district, or the seat is outside the release.
- **`incumbent_changed_district`** (boolean, can be null). True when the incumbent ran for a seat other than the one held. Within one boundary set that means another district. Across a boundary change it is false only when the district contested holds more of the held district's people than any other district does: council wards count people by the City's polls, and ridings by census population. A Mayor never changes district. A seat in a legislature outside the City counts as a change.  
  Null when the candidate is not an incumbent, or the boundaries cannot be compared: the 1997 federal, 1999 Ontario, 2004 federal and 2007 Ontario elections.
- **`predecessor_incumbent`** (boolean, can be null). For the first election of the amalgamated City on 10 November 1997: true when the Person sat on Metro Council or one of the six former councils on the eve of the election.  
  Null outside the Mayor and Councillor races of 1997, and for those races when no Person is linked. The release holds no rosters of the former school boards.
- **`campaign_url`** (string, can be null). The campaign website listed in the City's 2026 candidate list.  
  Null when no website was listed, and for every election before 2026.
- **`source_authority`** (string, never null). The organization whose record the row comes from: the election authority, or the Toronto Star where only the newspaper's printed results survive.  
  Values: `Toronto City Clerk`, `Elections Canada`, `Elections Ontario`, `Toronto Star`.
- **`source_url`** (string, never null). The published URL of each record the row comes from, separated by `;`. Where the record is a file inside an archive or one part of a page, the provenance supplement's `source_detail` names the file or part.

## `people`

People. One row per active Person. A Person is one human being who ran for office or held an office in the release. Each Person keeps the same `person_id` from version to version. When two Persons turn out to be the same person, one ID is retired and listed in `person_id_redirects`.

Key: `person_id`.

- **`person_id`** (string, never null). Stable ID of the Person.
- **`preferred_name`** (string, never null). The name the release uses for the Person, given name first. The names in `candidacies` are kept as each ballot printed them and are never changed to match it.
- **`house_of_commons_id`** (string, can be null). The House of Commons' person ID, from the member records of the 36th Parliament on.  
  Null for People who did not sit in the House from the 36th Parliament on.
- **`ontario_legislature_id`** (string, can be null). The Legislative Assembly of Ontario's member ID, the slug of its member profile.  
  Null for People who did not sit in the Assembly from the 36th Parliament on, including those known only from Elections Ontario's 1995 incumbent flag.
- **`wikidata_id`** (string, can be null). The Wikidata item for the Person, matched through their House of Commons seat or their Ontario member ID. Only members of the House or the Assembly are matched.  
  Null when the Person sat in neither, or has no Wikidata item.
- **`parlinfo_id`** (string, can be null). The Library of Parliament's ParlInfo person ID, as recorded on the matched Wikidata item.  
  Null when the Person has no House match or the Wikidata item records no ID.

## `person_id_redirects`

Retired Person IDs. One row per retired Person ID. Person IDs that a merge retired, each with the active Person that replaced it. Use this table to bring IDs saved from an earlier version up to date.

Key: `retired_person_id`.
Joins: `person_id` to `people`.

- **`retired_person_id`** (string, never null). The Person ID that was retired.
- **`person_id`** (string, never null). The active Person ID that replaced it.

## `office_tenures`

Office tenures. One row per piece of evidence that a Person held an office. Evidence that a Person held one office in one body, with dates. Each row is one piece of evidence, not one term of office: a councillor has a row for each general election they sat through, and a member of a legislature a row for each Parliament. The release uses these rows to set incumbency. Appointments to fill a vacancy are included.

Key: `office_tenure_id`.
Joins: `person_id` to `people`, `district_id` to `districts`.

- **`office_tenure_id`** (string, never null). Stable ID of the tenure row.
- **`person_id`** (string, never null). The Person who held the office.
- **`represented_body`** (string, never null). The body in which the office was held.
- **`office_type`** (string, never null). The office held.  
  Values: `mayor`, `councillor`, `trustee`, `mp`, `mpp`.
- **`district_id`** (string, can be null). The district of the seat held.  
  Null when the source gives no district within the release.
- **`started_on`** (date, can be null). The first day of the tenure, bounded as `started_on_precision` says.  
  Null when the start is unknown.
- **`started_on_precision`** (string, never null). `election_date`: the day of the election the Person won. `appointment_date`: the day Council appointed them. `on_or_before`: they were in office by that day. `unknown`: the source gives no start.  
  Values: `election_date`, `appointment_date`, `on_or_before`, `unknown`.
- **`ended_on`** (date, can be null). The last day of the tenure, bounded as `ended_on_precision` says.  
  Null when the tenure is ongoing.
- **`ended_on_precision`** (string, never null). `exact`: the last day of the term as the House or the Assembly records it. `at_or_after_reference`: the Person was still in office on the eve of the next general election, the date given. `before_or_at_reference`: the Person had left by that date. `ongoing`: the Person is still in office.  
  Values: `exact`, `at_or_after_reference`, `before_or_at_reference`, `ongoing`.
- **`entry_method`** (string, never null). Whether the Person came to the office by election or by appointment.  
  Values: `election`, `appointment`, `unknown`.
- **`source_authority`** (string, never null). The organization whose record supports the row.
- **`source_url`** (string, can be null). The published URL of each record that supports the row, separated by `;`. The full evidence is in the provenance supplement.  
  Null when the evidence cites no published URL.
- **`spell_id`** (string, can be null). Groups the rows of one unbroken stretch of service by one Person in one office and body.  
  Null when the start of the tenure is unknown.

## `parties`

Parties. One row per Party. A Party is one registered party within one jurisdiction. A Party is a relationship of a Candidacy, never a permanent attribute of a Person.

Key: `party_id`.

- **`party_id`** (string, never null). Stable ID of the Party.
- **`jurisdiction`** (string, never null). The election authority with which the Party is registered.  
  Values: `elections_canada`, `elections_ontario`.
- **`canonical_name`** (string, never null). The name the release uses for the Party.
- **`party_name_raw`** (string, never null). The Party's name exactly as the source printed it.

## `districts`

Districts. One row per district. A district is one ward, riding or trustee area as drawn in one boundary set. The shapes are in `districts.gpkg`, which holds the same columns and a geometry for every district with a shape.

Key: `district_id`.

- **`district_id`** (string, never null). Stable ID of the district.
- **`represented_body`** (string, never null). The body whose seats the district elects.
- **`boundary_regime`** (string, never null). The set of boundaries the district belongs to.
- **`official_district_id`** (string, never null). The authority's own number or code for the district.
- **`district_name`** (string, never null). The district's name as the authority gave it.
- **`geographic_name`** (string, can be null). A place name for a numbered ward. For council wards it is the ward's official name. For trustee wards it is either the official name or the names of the council wards the trustee ward joins, separated by `;`, as `name_provenance` says.  
  Null for districts whose `district_name` is already a place name, and for wards with no name on record.
- **`district_display_name`** (string, can be null). `district_name` and `geographic_name` joined, for display.  
  Null when `geographic_name` is null.
- **`name_provenance`** (string, can be null). `official`: `geographic_name` is the authority's name for the ward. `derived_from_city_wards`: it lists the council wards that make up the trustee ward.  
  Values: `official`, `derived_from_city_wards`.  
  Null when `geographic_name` is null.
- **`geometry_status`** (string, never null). `available` when `districts.gpkg` holds the district's shape.  
  Values: `available`, `not_acquired`.
- **`geometry_missing_reason`** (string, can be null). Why the release has no shape for the district.  
  Values: `council_boundary_regime_not_supported`, `district_geometry_not_acquired_for_represented_body`, `federal_district_geometry_not_acquired`, `provincial_district_geometry_not_acquired`, `school_board_district_geometry_not_acquired`.  
  Null when a shape is available.
- **`geometry_source_authority`** (string, can be null). The organization that published the shape.  
  Null when no shape is available.
- **`geometry_source_resource`** (string, can be null). The title of the boundary file the shape comes from. Trustee ward shapes are unions of council ward shapes, and Ontario's 1999 and 2007 ridings use the federal ridings that the Representation Acts of 1996 and 2005 adopted.  
  Null when no shape is available.
- **`geometry_source_year`** (integer, can be null). The year of the boundary file the shape comes from.  
  Null when no shape is available.
- **`geometry_source_url`** (string, can be null). The published URL of the boundary file, or of the page it was saved from.  
  Null when no shape is available.
