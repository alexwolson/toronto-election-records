# Toronto Election Results

Version `dev-080ec46`

Toronto Election Results records the candidates and results of elections held within the City of
Toronto from 1993 to 2026. It covers the City's Mayor and Council, the trustees of
the four school boards, and the members of Parliament and of the Ontario Legislature elected in the
City's ridings. Before the City's amalgamation in 1998 it covers the 1994 municipal elections of
the six former municipalities and Metropolitan Toronto, the 1993 federal election and the 1995
Ontario election. A person's runs for office are joined under one Person ID where evidence shows
they are the same person, so a career can be followed across offices and years.

## What the package holds

| Table | One row per | Rows |
|---|---|---:|
| `candidacies` | candidate in one Contest | 97 |
| `contests` | race for one or more seats | 15 |
| `elections` | general election or by-election | 10 |
| `people` | Person | 94 |
| `person_id_redirects` | retired Person ID | 1 |
| `office_tenures` | piece of evidence that a Person held an office | 50 |
| `parties` | registered party | 25 |
| `districts` | ward, riding or trustee area | 34 |

Each table is in `data/` in four formats with the same rows and columns: CSV, Parquet, Stata
(`.dta`) and R (`.rds`). `data/districts.gpkg` holds the shapes of the 20 districts
that have one. `CODEBOOK.md`, also as `CODEBOOK.pdf`, describes every column, its units and what a
null means. `datapackage.json` lists every data file with its SHA-256 checksum and every column
with its type.

## Quick start

In R and Python, the loaders download a version, check every file against its checksum and keep a
copy for later sessions.

```r
# R
install.packages("torontoelections")
candidacies <- torontoelections::te_candidacies(version = "dev-080ec46")
```

```python
# Python: pip install toronto-elections
import torontoelections as te
candidacies = te.candidacies(version="dev-080ec46")
```

The files in this package can also be read directly:

```r
candidacies <- readRDS("data/candidacies.rds")
```

```python
import pandas as pd
candidacies = pd.read_parquet("data/candidacies.parquet")
```

In Stata (14 or later), unzip the package and open a table's `.dta` file from the package's
folder. Its variables carry the codebook's labels, and booleans are 0 and 1 with the value labels
`false` and `true`.

```stata
use "data/candidacies.dta", clear
```

To check a file, run Stata's `checksum` on it and compare the checksum and size it prints with the
`cksum` and `bytes` columns of the file's row in `checksums.csv`. They are the same POSIX CRC.

```stata
checksum "data/candidacies.dta"
```

## Before you analyse

- `person_id` is null for 3 Candidacies, where the evidence does not establish who
  ran. The other 94 have a Person.
- 6 Candidacies are joined to their Person under the build's structural rules, with
  no source about the person. `person_link_basis` marks them as `structural`. Repeating an
  analysis without them shows whether a result depends on them.
- `incumbent` is null where the release holds no roster that can settle it: Mayor and Council in
  1994 and 1997, and every trustee race before 2026.
- Turnout is null for every trustee race, for municipal races from 1994 to 2001 and for the 2026
  municipal election.
- Districts in different boundary sets (`boundary_regime`) cover different areas and cannot be
  compared directly.
- The build's Endorsement tables are held back from this release. Their coverage is too thin to
  support analysis, and an absent endorsement in them does not mean there was none.

`KNOWN_ISSUES.md` lists every documented limitation. `VALIDATION.md` summarizes how the data were
checked. `DATASHEET.md` answers the questions of Datasheets for Datasets. `CHANGELOG.md` records
what changed in each version.

## Versions and identifiers

The version name is the tag of the build it was made from. File names inside the package stay the
same from version to version. `candidacy_id`, `contest_id`, `event_id`, `district_id` and
`person_id` stay the same across versions. When two Persons turn out to be one, the retired ID is
listed in `person_id_redirects` with the ID that replaced it.

This version was made from commit `080ec46` of the build repository,
/var/folders/gl/dg61l3jn6vv51rk7ctrlzqgr0000gn/T/tmp76n8sc2y/toronto-election-results. The code and records behind every value are in the provenance supplement,
`toronto-election-records-dev-080ec46-provenance.zip`.

## Citing

Olson, A., & Elliott, M. (2026). *Toronto Election Results* (Version dev-080ec46) [Data set].
Development build, without a DOI.

`CITATION.cff` gives the same citation in machine-readable form.

## Licence

The data and documentation are licensed under the Creative Commons Attribution 4.0 International
Licence (CC BY 4.0). The records they are built from remain subject to their publishers' terms;
`LICENSE` gives the notices those terms require.
